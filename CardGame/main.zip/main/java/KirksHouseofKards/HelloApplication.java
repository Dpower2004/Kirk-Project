package KirksHouseofKards;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Button START = new Button();
        Button ACHIEVEMENTS = new Button();
        Button SAVE = new Button();
        Button CLOSE = new Button();
        Label TITLE = new Label("Kirk's House of Kards");

        Menu startMenu = new Menu();
        VBox OptionButtons = new VBox();
        OptionButtons.getChildren().addAll(START,ACHIEVEMENTS,SAVE,CLOSE,TITLE);

        HBox titleimage = new HBox();
        titleimage.getChildren().addAll(TITLE);



        Scene scene = new Scene(fxmlLoader.load(), 1366, 768);
        stage.setTitle("Krik's House of Kards");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}